package com.himichat.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root, content, topBar, nav;
    private SharedPreferences prefs;
    private int accent = Color.rgb(238, 92, 157);
    private int pageBg = Color.rgb(255, 245, 250);
    private int cardBg = Color.WHITE;
    private String currentPage = "Чаты";
    private final String[] themeNames = {"Розовый", "Фиолетовый", "Голубой", "Зелёный", "Чёрный", "Красный", "Жёлтый"};
    private final int[] themeColors = {
        Color.rgb(238,92,157), Color.rgb(142,92,220), Color.rgb(65,155,230),
        Color.rgb(55,170,125), Color.rgb(45,48,58), Color.rgb(225,75,75), Color.rgb(225,170,45)
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("himi", MODE_PRIVATE);
        int saved = prefs.getInt("accent", themeColors[0]);
        setThemeColor(saved);
        showPage("Чаты");
    }

    private void setThemeColor(int color) {
        accent = color;
        pageBg = (color == Color.BLACK || color == Color.rgb(45,48,58))
            ? Color.rgb(28,29,34) : blend(color, Color.WHITE, 0.91f);
        cardBg = (pageBg == Color.rgb(28,29,34)) ? Color.rgb(48,49,56) : Color.WHITE;
        if (prefs != null) prefs.edit().putInt("accent", color).apply();
    }

    private int blend(int a, int b, float ratio) {
        return Color.rgb(
            (int)(Color.red(a)*ratio + Color.red(b)*(1-ratio)),
            (int)(Color.green(a)*ratio + Color.green(b)*(1-ratio)),
            (int)(Color.blue(a)*ratio + Color.blue(b)*(1-ratio)));
    }
    private int textColor() { return pageBg == Color.rgb(28,29,34) ? Color.WHITE : Color.rgb(45,39,44); }

    private TextView label(String text, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(textColor());
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(16, 12, 16, 12);
        return t;
    }
    private GradientDrawableLike shape(int color) { return new GradientDrawableLike(color); }
    private void showPage(String page) {
        currentPage = page;
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(pageBg);
        setContentView(root);
        topBar = new LinearLayout(this); topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(8, 12, 8, 12); topBar.setBackgroundColor(cardBg);
        TextView title = label("💗 HIMI CHAT", 21, true); title.setTextColor(accent);
        topBar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = label("DEMO", 11, true); badge.setTextColor(accent); topBar.addView(badge);
        root.addView(topBar);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(12, 12, 12, 16);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        nav = new LinearLayout(this); nav.setBackgroundColor(cardBg); nav.setPadding(2, 5, 2, 5);
        root.addView(nav);
        addNav("Чаты", "💬"); addNav("Подарки", "🎁"); addNav("Настройки", "⚙️");
        if (page.equals("Чаты")) chats();
        else if (page.equals("Подарки")) gifts();
        else settings();
        AlphaAnimation anim = new AlphaAnimation(0.65f, 1f); anim.setDuration(180); content.startAnimation(anim);
    }
    private void addNav(String name, String icon) {
        TextView b = new TextView(this); b.setText(icon + "\n" + name); b.setGravity(Gravity.CENTER);
        b.setTextSize(12); b.setTextColor(currentPage.equals(name) ? accent : textColor());
        b.setPadding(4, 7, 4, 7);
        nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
        b.setOnClickListener(v -> showPage(name));
    }
    private void card(View v) {
        LinearLayout wrap = new LinearLayout(this); wrap.setPadding(6, 4, 6, 4);
        wrap.setBackground(shape(cardBg));
        wrap.addView(v, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 5, 0, 5); content.addView(wrap, lp);
    }
    private void chats() {
        content.addView(label("Сообщения", 25, true));
        content.addView(label("Демонстрационный интерфейс — сообщения пока не отправляются на сервер.", 13, false));
        String[][] rows = {
            {"🌸","Команда HIMI","Добро пожаловать в HIMI CHAT!","12:40"},
            {"🦊","Лисёнок","Отправил(а) подарок 🎁","Вчера"},
            {"🌙","Ночной чат","Хорошего вечера!","Пн"}
        };
        for (String[] r : rows) {
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            TextView avatar = label(r[0], 26, true); row.addView(avatar);
            LinearLayout texts = new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL);
            TextView name = label(r[1], 16, true); TextView msg = label(r[2], 13, false);
            texts.addView(name); texts.addView(msg); row.addView(texts, new LinearLayout.LayoutParams(0,-2,1));
            row.addView(label(r[3], 11, false)); card(row);
        }
        Button info = button("＋  Новый чат (демо)");
        content.addView(info);
        info.setOnClickListener(v -> toast("Подключение реальных чатов ещё не настроено"));
    }
    private void gifts() {
        content.addView(label("🎁 Магазин подарков", 24, true));
        content.addView(label("500 демонстрационных подарков · выбери любой", 13, false));
        EditText search = new EditText(this); search.setSingleLine(true); search.setHint("Поиск подарка");
        content.addView(search);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list);
        String[] icons = {"🌹","🧸","💎","🎀","🦋","🍓","🌈","⭐","🍰","🐱","🎈","💐","🪄","👑","☀️","🌙"};
        for (int i=1; i<=500; i++) {
            final int number = i;
            String title = icons[(i-1)%icons.length] + " Подарок #" + String.format(Locale.US,"%03d",i);
            TextView item = label(title + "     ·     " + (i%5==0 ? "Редкий" : "Обычный"), 15, i%5==0);
            item.setBackground(shape(cardBg));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,3,0,3);
            list.addView(item,lp);
            item.setOnClickListener(v -> toast("Выбран " + title + " (демо)"));
        }
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) {
                String q=s.toString().toLowerCase(Locale.ROOT);
                for(int i=0;i<list.getChildCount();i++) {
                    View child=list.getChildAt(i);
                    child.setVisibility(((TextView)child).getText().toString().toLowerCase(Locale.ROOT).contains(q)?View.VISIBLE:View.GONE);
                }
            }
            public void afterTextChanged(android.text.Editable e) {}
        });
    }
    private void settings() {
        content.addView(label("⚙️ Настройки", 25, true));
        content.addView(label("Оформление", 17, true));
        Button colors = button("🎨  Выбрать цвет темы");
        content.addView(colors);
        colors.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Цвет HIMI CHAT")
            .setItems(themeNames, (d, which) -> { setThemeColor(themeColors[which]); showPage("Настройки"); toast("Тема изменена"); }).show());
        Button custom = button("🌈  Свой цвет");
        content.addView(custom);
        custom.setOnClickListener(v -> {
            String[] names={"Розовый","Сиреневый","Небесный","Мятный","Персиковый"};
            int[] colors={Color.rgb(238,92,157),Color.rgb(185,140,225),Color.rgb(110,190,235),Color.rgb(115,205,170),Color.rgb(245,165,130)};
            new AlertDialog.Builder(this).setTitle("Пастельные оттенки")
                .setItems(names,(d,w)->{setThemeColor(colors[w]);showPage("Настройки");}).show();
        });
        content.addView(label("Дополнительно", 17, true));
        String[] opts={"Анимации интерфейса: включены","Уведомления: демо","Приватность: демо","Профиль: демо","О приложении"};
        for(String s:opts){ Button b=button(s); content.addView(b); b.setOnClickListener(v->toast("Этот раздел будет добавлен в следующих версиях")); }
        content.addView(label("Версия 1.0 · HIMI CHAT starter", 12, false));
    }
    private Button button(String text) {
        Button b=new Button(this); b.setText(text); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackground(shape(accent)); return b;
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }

    private class GradientDrawableLike extends android.graphics.drawable.GradientDrawable {
        GradientDrawableLike(int color) { setColor(color); setCornerRadius(22f); }
    }
}